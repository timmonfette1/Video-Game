#!/bin/bash
#
#

cd bin

java GameMain

cd ..
